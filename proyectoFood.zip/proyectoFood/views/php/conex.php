<?php

$servidor="localhost";
$usuario="root";
$clave="";
$bd="edusoftg_estudiantes";

mysql_connect("$servidor","$usuario","$clave");
mysql_select_db("$bd");

?>
